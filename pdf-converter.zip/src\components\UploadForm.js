﻿import React, { useState } from 'react';
import axios from 'axios';

export default function UploadForm() {
    const [files, setFiles] = useState([]);
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!files.length) return;
        const formData = new FormData();
        for (const f of files) formData.append('pdfs', f);

        try {
            setLoading(true);
            const res = await axios.post('/api', formData, { responseType: 'blob' });
            const url = window.URL.createObjectURL(new Blob([res.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'converted_files.zip');
            document.body.appendChild(link);
            link.click();
        } catch (err) {
            console.error(err);
            alert('Error al convertir PDFs');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className='bg-white p-6 rounded shadow-md w-full max-w-md mx-auto mt-20'>
            <h1 className='text-xl font-bold mb-4 text-center'>Convertir PDFs a TXT</h1>
            <form onSubmit={handleSubmit}>
                <input
                    type='file'
                    accept='application/pdf'
                    multiple
                    onChange={e => setFiles(Array.from(e.target.files))}
                    className='mb-4 w-full'
                />
                <button type='submit' className='bg-blue-500 text-white px-4 py-2 rounded w-full'>
                    {loading ? 'Convirtiendo...' : 'Convertir y Descargar'}
                </button>
            </form>
        </div>
    );
}
