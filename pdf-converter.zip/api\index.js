﻿import multer from 'multer';
import { tmpdir } from 'os';
import fs from 'fs';
import archiver from 'archiver';
import pdfToText from './converters/pdfToText.js';

const upload = multer({ dest: tmpdir() });
export const config = { api: { bodyParser: false } };

export default upload.array('pdfs')(async (req, res) => {
    try {
        const files = req.files;
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename=converted_files.zip');

        const archive = archiver('zip');
        archive.pipe(res);

        for (const file of files) {
            const content = await pdfToText(file.path);
            archive.append(content, { name: ${file.originalname}.txt });
            fs.unlinkSync(file.path);
        }

        await archive.finalize();
    } catch (err) {
        console.error(err);
        res.status(500).send('Error al convertir PDFs');
    }
});
